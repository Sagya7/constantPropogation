import syntaxtree.*;
import visitor.*;
import java.io.*;
import java.util.*;
import java.util.stream.*;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class P3 {
	public static void main(String [] args) {
		GJDepthFirst v = new GJDepthFirst();
		GJDepthFirstST<String, SymbolTable> v1 = new GJDepthFirstST<String, SymbolTable>();
		try{
				try
				{
					FileInputStream stream = null;
					stream = new FileInputStream("test16.java");
					Node root = new TACoJavaParser(stream).Goal();
					//System.out.println("Program parsed successfully");
					List<String> s1 = new ArrayList<>();
					SymbolTable st = new SymbolTable();
					root.accept(v1, st);

	
					ArrayList<String> listOfVarnames 
					= st.var_info.keySet().stream().collect( 
					   Collectors.toCollection(ArrayList::new)); 
		
					ArrayList<String> listOfVarTypes
					= st.var_info.values().stream().collect( 
						  Collectors.toCollection(ArrayList::new));
		
					s1.addAll(listOfVarnames);
					s1.addAll(listOfVarTypes);
					
					//populate symbol table
					root.accept(v, s1);
					int i = 0;
					while(i < s1.size())
					{
						System.out.println(s1.get(i));
						i++;
					}
					stream.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			catch (Exception e)
			{
			 System.out.println(e.toString());
			}
	}
}
