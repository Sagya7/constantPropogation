package visitor;
import java.io.*;
import java.util.*;

public class SymbolTable{
    public HashMap<String, String> var_info = new HashMap<>();
}