//some unused variables.
class test7 {
    public static void main(String[] a) {
      int i;
      int j;
      int k;
      int m;
      int n;
      boolean e;
      i = 10;
      j = 1;
      k = 1;
      m = 1;
      n = 15;
      e = m < i;        
      for(i = m; i < n; i = i + m)
      {
        j = i * j;
        i = i - m;
        k = k * k;

      }
      System.out.println(k);
    }
  }