//redeclaring same variable name in another function.

class test10{
    public static void main(String[] a){
        Fac10 obj1;
        int temp1;
        int const1;
        
        obj1 = new Fac10();
        const1 = 10;
        temp1 = obj1.ComputeFac(const1);
        System.out.println(temp1);
    }
}

class Fac10 {
    public int ComputeFac(int num){
        int temp1;
        int const1;
        temp1 = 50;
        const1 = 60;
        System.out.println(const1);
        System.out.println(temp1);
        return num ;
    }
}