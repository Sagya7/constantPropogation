class test16 {
  public static void main(String[] a) {
    Fact16 obj1;
    Fact16_1 obj2;
    int temp1;
    int temp2;
    int const1;
    obj1 = new Fact16();
    obj2 = new Fact16_1();
    const1 = 10;
    temp1 = obj1.ComputeFac(10);
    temp2 = obj2.ComputeFac(10);
    const1 = obj2.i;
    System.out.println(temp1);
  }
}
class Fact16 {
  public int ComputeFac(int num) {
    int num_aux;
    int const1;
    int const2;
    boolean e1;
    int temp1;
    int temp2;
    int[] arr;
    Fact16_1 obj;
    obj = new Fact16_1();
    const1 = obj.i;
    obj.i = const1;
    const2 = 20;
    obj.i = 20;
    arr = new int[const1];
    const2 = arr.length;
    e1 = num < const1;
    e1 = !e1;
    if (e1)
      num_aux = 1;
    else {
      const2 = 1;
      temp1 = num - 1;
      temp2 = this.ComputeFac(temp1);
      num_aux = num * temp2;
    }
    return num_aux;
  }
}
class Fact16_1 {
  int i;
  boolean k;
  int l;
  public int ComputeFac(int num) {
    int num_aux;
    int const1;
    int const2;
    boolean e1;
    int temp1;
    int temp2;
    int[] arr;
    const1 = 10;
    temp1 = 1;
    temp2 = 2;
    arr = new int[10];
    const2 = 10;
    arr[1] = 1;
    temp2 = arr[1];
    e1 = num < 10;
    e1 = !e1;
    if (e1)
      num_aux = 1;
    else {
      const2 = 1;
      temp1 = num - 1;
      temp2 = this.ComputeFac(temp1);
      num_aux = 1;
    }
    i = 10;
    e1 = num < 10;
    return 1;
  }
}
