//some unused variables.
class test1 {
  public static void main(String[] a) {
    int i;
    int j;
    i = 1;
    j = 2;
    System.out.println(i);
    System.out.println(j);
  }
}