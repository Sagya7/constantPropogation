//some unused variables.
class test6 {
    public static void main(String[] a) {
      int i;
      int j;
      int k;
      int m;
      boolean e;
      i = 10;
      j = 1;
      k = 1;
      m = 1;
      e = m < i;        
      while(e)
      {
        j = i * j;
        i = i - m;
        k = k * k;

      }
      System.out.println(k);
    }
  }