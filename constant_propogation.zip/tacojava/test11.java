// multiple classes
class test11{
    public static void main(String[] a){
        Fact obj1;
        Fact2 obj2;
        int temp1;
        int temp2;
        int const1;
        
        obj1 = new Fact();
        obj2 = new Fact2();
        const1 = 10;
        temp1 = obj1.ComputeFac(const1);
        temp2 = obj2.ComputeFac(const1);
        System.out.println(temp1);
    }
}

class Fact {
    public int ComputeFac(int num){
        int num_aux ;
        int const1;
        int const2;
        boolean e1;
        int temp1;
        int temp2;


        const1 = 1;
        e1 = num < const1; 
        if (e1)
            num_aux = 1 ;
        else{
            const2 = 1;
            temp1 = num - const2;
            temp2 = this.ComputeFac(temp1);
            num_aux = num * temp2;
        }
        return num_aux ;
    }
}

class Fact2 {
    int i;
    public int ComputeFac(int num){
        int num_aux ;
        int const1;
        int const2;
        boolean e1;
        int temp1;
        int temp2;

        const1 = 10;
        e1 = num < const1; 
        if (e1)
            num_aux = 1 ;
        else{
            const2 = 1;
            temp1 = num - const2;
            temp2 = this.ComputeFac(temp1);
            num_aux = 1;
        }
        i = const1;
        e1 = num < i; 
        return num_aux ;
    }
    public int ComputeFac2(int num){
        int num_aux ;
        int const1;
        int const2;
        boolean e1;
        int temp1;
        int temp2;

        const1 = 15;
        e1 = num < const1; 
        if (e1)
            num_aux = 1 ;
        else{
            const2 = 1;
            temp1 = num - const2;
            temp2 = this.ComputeFac(temp1);
            num_aux = 1;
        }
        i = const1;
        e1 = num < i; 
        return num_aux ;
    }
}