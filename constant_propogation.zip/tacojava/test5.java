//some unused variables.
class test5 {
    public static void main(String[] a) {
      int i;
      int j;
      int g;
      boolean e;
      i = 10;
      j = 5;
      e = i < j;        
      if(e)
      {
        g = i & j;
      }
      else
      {
        g = i * j;
      }
      g = 3;    
      System.out.println(g);
    }
  }