//some unused variables.
class test2 {
    public static void main(String[] a) {
      int i;
      int j;
      int k;
      i = 1;
      j = i;
      k = j;
      System.out.println(i);
      System.out.println(j);
      System.out.println(k);
    }
  }