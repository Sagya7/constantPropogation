//Some variables have same values in if and else
class t5 {
    public static void main(String[] a) {
     int x;
     int y;
     int z;
     dum d;
     x = 9;
     y = 8;
     z = 7;
     d = new dum();     
     y = d.fun(z);
     z = x + y;
     System.out.println(x);
    }
  }

  class dum {
    public int fun(int num) {
        int x;
        x = 8;
        return x;
    }
}