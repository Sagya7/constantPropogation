//Some variables have same values in if and else
class t1 {
    public static void main(String[] a) {
     int x;
     int y;
     int z;
     int r1;
     int r2;
     int r3;
     boolean e1;
     x = 5;
     y = 6;
     z = 7;
     e1 = x < y;
     if(e1)
     {
         y = 6;
         z = 7;
         x = 8;
     }
     else
     {
         y = 6;
         z = 7;
         x = 9;
     }

     r1 = x + y;
     r2 = r1 + z;
     r3 = r1 + r2;
     System.out.println(r3);
    }
  }