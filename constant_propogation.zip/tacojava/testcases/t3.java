//inside while loop some constants used
class t3 {
    public static void main(String[] a) {
     int x;
     int y;
     int z;
     int w;
     int r1;
     int r2;
     int r3;
     boolean e1;
     x = 5;
     y = 10;
     z = 7;
     w = 1;
     e1 = x < y;
     while(e1)
     {
         x = x + w;
         z = 8;
         e1 = x < y;
     }

     r1 = x + y;
     r2 = r1 + z;
     r3 = r1 + r2;
     System.out.println(r3);
    }
  }