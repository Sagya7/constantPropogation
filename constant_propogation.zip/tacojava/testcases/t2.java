//some unused variables.
class t2 {
    public static void main(String[] a) {
     int x;
     int y;
     int z;
     int r1;
     int r2;
     int r3;
     boolean e1;
     x = 5;
     y = 6;
     z = 7;
     e1 = x < y;
     if(e1)
     {
        System.out.println(x);
     }
     else
     {
        System.out.println(x);
     }
    }
  }