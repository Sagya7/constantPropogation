//some unused variables.
class test4 {
    public static void main(String[] a) {
      int i;
      int j;
      int m;
      int g;
      boolean e;
      i = 10;
      j = 4;
      m = 7;
      e = i < j;        
      if(e)
      {
        g = i * j;
      }
      else
      {
        g = i * j;
      }    
      System.out.println(g);
    }
  }