//some unused variables.
class test3 {
    public static void main(String[] a) {
      int i;
      int j;
      int k;
      i = 1;
      j = 2;
      k = i + j;
      System.out.println(i);
      System.out.println(j);
      System.out.println(k);
    }
  }