//class extends..

class test12{
    public static void main(String[] a){
        Fact12 obj1;
        Fact12_1 obj2;
        int temp1;
        int temp2;
        int const1;
        
        obj1 = new Fact12();
        obj2 = new Fact12_1();
        const1 = 10;
        temp1 = obj1.ComputeFac(const1);
        temp2 = obj2.ComputeFac(const1);
        System.out.println(temp1);
    }
}

class Fact12 extends Fact12_1{
    public int ComputeFac(int num){
        int num_aux ;
        int const1;
        int const2;
        boolean e1;
        int temp1;
        int temp2;


        const1 = i;
        e1 = num < const1; 
        if (e1)
            num_aux = 1 ;
        else{
            const2 = 1;
            temp1 = num - const2;
            temp2 = this.ComputeFac(temp1);
            num_aux = num * temp2;
        }
        return num_aux ;
    }
}

class Fact12_1 {
    int i;
    boolean k;
    int l;
    public int ComputeFac(int num){
        int num_aux ;
        int const1;
        int const2;
        boolean e1;
        int temp1;
        int temp2;

        const1 = 10;
        e1 = num < const1; 
        if (e1)
            num_aux = 1 ;
        else{
            const2 = 1;
            temp1 = num - const2;
            temp2 = this.ComputeFac(temp1);
            num_aux = 1;
        }
        i = const1;
        e1 = num < i; 
        return num_aux ;
    }
}