//Simple Function call

class test9{
    public static void main(String[] a){
        Fac9 obj1;
        int temp1;
        int const1;
        
        obj1 = new Fac9();
        const1 = 10;
        temp1 = obj1.ComputeFac(const1);
        System.out.println(temp1);
    }
}

class Fac9 {
    public int ComputeFac(int num){
        num = 10;
        return num ;
    }
}